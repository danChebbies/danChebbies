<?php
include "incl/scores/updateGJUserScore.php";
?>
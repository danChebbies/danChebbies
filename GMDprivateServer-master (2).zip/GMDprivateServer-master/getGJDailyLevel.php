<?php
include "incl/levels/getGJDailyLevel.php";
?>
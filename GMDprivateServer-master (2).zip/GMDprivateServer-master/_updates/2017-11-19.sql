ALTER TABLE `roles` ADD `modBadgeLevel` int(11) NOT NULL AFTER `commentColor`;

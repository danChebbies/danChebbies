<?php
include "incl/comments/uploadGJAccComment.php";
?>